function Home1 ( )
{
  document.getElementById("Home").value = "होम";
  document.getElementById("Home").style.color = "#4DEEEA";
  setTimeout ( "Home2()", 200 );
}
function Home2 ( )
{
  document.getElementById("Home").value = "Home";
  document.getElementById("Home").style.color = "#fff";
}
